namespace ProjetoEscola_API.Models
{
    public class Aluno
    {
        public int Id { get; set; }
        public string? Ra { get; set; }
        public string? Nome { get; set; }
        public int CodCurso { get; set; }
        
        public override string ToString()
        {
            return (Id + ", " + Ra + ", " + Nome);
        }
    }

}