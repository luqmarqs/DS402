namespace ProjetoEscola_API.Models
{
    public class Curso
    {
        public int Id { get; set; }
        public int? CodCurso { get; set; }
        public string? NomeCurso { get; set; }
        public string Periodo { get; set; }
        
    
    }

}